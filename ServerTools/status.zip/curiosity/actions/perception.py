# Module perception



class Visual:
    def __init__():
        print 'Visual system not implemented yet'
